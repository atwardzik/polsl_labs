package controller;

import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.ListView;
import javafx.scene.input.KeyCode;
import javafx.scene.input.KeyCodeCombination;
import javafx.scene.input.KeyCombination;
import javafx.scene.layout.HBox;
import lombok.Setter;
import model.Issue;

/**
 * Controller responsible for displaying the list of all issues in the application.
 * This class initializes and manages the Issues List view, including configuring
 * list cell rendering, handling user interaction (mouse double-click and keyboard
 * shortcuts), and delegating navigation to the main application window controller.
 *
 * @author Artur Twardzik
 * @version 0.3
 */
public class IssuesListController {
    /**
     * The ListView displaying all issues in the system.
     */
    @FXML
    private ListView<Issue> issuesList;

    /**
     * Root container of the issues list view, used for scene-level event handling.
     */
    @FXML
    private HBox issuesListScene;

    /**
     * Reference to the main window controller used for navigation and shared data access.
     */
    @Setter
    private MainAppWindowController parent;

    /**
     * Callback used to report exceptions or errors back to the parent controller.
     */
    @Setter
    private ChildControllerListener exceptionListener;

    /**
     * Initializes the issues list view by configuring its cell factory,
     * setting up mouse and keyboard shortcuts for opening issue details,
     * loading issue data from the parent controller, and establishing focus
     * behavior when the scene becomes active.
     */
    public void initializeData() {
        issuesList.setCellFactory(lv -> new IssueCell());
        issuesList.setOnMouseClicked(event -> {
            if (event.getClickCount() == 2) {
                Issue selectedIssue = issuesList.getSelectionModel().getSelectedItem();
                if (selectedIssue != null) {
                    try {
                        parent.setIssuePane(selectedIssue);
                    } catch (Exception e) {
                        if (this.exceptionListener != null) {
                            this.exceptionListener.onError(e);
                        }
                    }
                }
            }
        });
        issuesList.sceneProperty().addListener((obs, old, newScene) -> {
            if (newScene != null) {
                newScene.getAccelerators().put(
                        new KeyCodeCombination(KeyCode.O, KeyCombination.SHORTCUT_DOWN),
                        () -> {
                            Issue selected = issuesList.getSelectionModel().getSelectedItem();
                            if (selected != null) {
                                parent.setIssuePane(selected);
                            }
                        }
                );
            }
        });
        ObservableList<Issue> list = FXCollections.observableArrayList();

        list.addAll(parent.getManager().getAllIssues());
        issuesList.setItems(list);
        issuesList.getSelectionModel().select(0);

        issuesListScene.sceneProperty().addListener((obs, oldScene, newScene) -> {
            if (newScene != null) {
                issuesList.requestFocus();
            }
        });
    }

    /**
     * Refreshes the ListView of filtered issues. Useful when external changes occur
     * that modify the displayed issues (e.g., issue edited elsewhere).
     */
    public void refreshIssues() {
        int current = issuesList.getSelectionModel().getSelectedIndex();
        ObservableList<Issue> list = FXCollections.observableArrayList();

        list.addAll(parent.getManager().getAllIssues());
        issuesList.setItems(list);
        issuesList.getSelectionModel().select(current);
        issuesList.refresh();
    }
}